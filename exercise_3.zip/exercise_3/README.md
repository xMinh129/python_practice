# Creating a Full Stack Web Application with Python, NPM, Webpack and React

Table Dashboard
